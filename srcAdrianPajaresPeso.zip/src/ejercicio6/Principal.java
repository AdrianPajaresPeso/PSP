package ejercicio6;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio6 e = new Ejercicio6();
		e.menu6("DirectorioPadre");
	}

}
