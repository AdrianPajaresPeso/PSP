package ejercicio4;

public class Principal {

	public static void main(String[] args) {
		Ejercicio4 e = new Ejercicio4();
		e.obtenerValorParametroProperties("saludo", "listaParametros.properties");
		e.obtenerValorParametroStreams("saludo", "listaParametros.properties");

	}

}
