package ejercicio2;

public class Principal {

	public static void main(String[] args) {
		Ejercicio2 e = new Ejercicio2();
		e.copiarFichero("DirectorioPadre/Subdirectorio3/Fichero3");

	}

}
