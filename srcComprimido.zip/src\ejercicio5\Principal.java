package ejercicio5;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio5 e = new Ejercicio5();
		e.menu();
	}

}
