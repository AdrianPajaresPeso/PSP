package ejercicio1;

public class Principal {
	public static void main(String[] args) {
		Ejercicio1 e = new Ejercicio1();
		e.obtenerNumeroRepeticiones("DirectorioPadre/Subdirectorio3/Fichero3_copy.txt", "app");
	}
}
