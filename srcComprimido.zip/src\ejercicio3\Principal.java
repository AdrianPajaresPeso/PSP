package ejercicio3;

public class Principal {

	public static void main(String[] args) {
		Ejercicio3 e = new Ejercicio3();
		e.listDirectory("DirectorioPadre");

	}

}
