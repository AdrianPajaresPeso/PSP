package ejercicio7;

public class Principal {
	public void jas() {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ejercicio7 e = new Ejercicio7();
		e.menu7();
		
		
	}

}
