package ejercicio6;

public class Principal {

	public static void main(String[] args) {
		Ejercicio6 e = new Ejercicio6();
		e.searchPoketMonster();
	}

}
