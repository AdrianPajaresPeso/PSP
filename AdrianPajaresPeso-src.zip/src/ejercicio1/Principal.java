package ejercicio1;



public class Principal {
	public static void main(String[] args) {
		Ejercicio1 e = new Ejercicio1();
		e.nslookupCommand("216.58.209.68");
		e.nslookupCommand("google.es");
		
	
	}
}
