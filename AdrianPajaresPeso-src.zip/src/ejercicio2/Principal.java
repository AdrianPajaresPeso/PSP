package ejercicio2;

public class Principal {

	public static void main(String[] args) {
		Ejercicio2 e = new Ejercicio2();
		e.splitUrl("https://www.youtube.com/watch?v=_UOzQMWM0Tg");
		e.splitUrl("https://github.com/AdrianPajaresPeso/PSP/commit/4061859775e23ce20b54f140023bb3b5455a95ba#diff-f8440974184df74f5fa71dee08e66ddc2c47f6f7795b0a9163b831c46f0d10f9");
	}

}
